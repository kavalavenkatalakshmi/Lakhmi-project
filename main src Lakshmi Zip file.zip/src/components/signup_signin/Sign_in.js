import React, {useState} from 'react'
import { NavLink } from "react-router-dom"
import "./signup.css"

const Sign_in = () => {

const[logdata, setData] = useState({
    email:"",
    password:""
});
console.log(logdata);

const adddata = (e) =>{
    const {name, value} = e.target;

    setData(()=>{
        return {
            ...logdata,
            [name]:value
        }
    })
}


  return (
    <>
        <section>
            <div className="sign_container">
                <div className="sign_header">
                    <NavLink to="/"><img src="./logo.png" alt="krishnalogo"></img></NavLink>
                </div>
                <div className="sign_form">
                    <form>
                      <h1>Sign-In</h1>
                      <div className="form_data">
                        <label htmlFor="email">Email</label>
                        <input type="text"   
                        onChange={adddata}
                        value={logdata.email}
                        name="email" id="email" />
                      </div>
                      <div className="form_data">
                        <label htmlFor="password">Password</label>
                        <input type="password" 
                        onChange={adddata}
                        value={logdata.password}
                        name="password" placeholder="Atleast 6 char" id="password" />
                      </div>
                      
                <NavLink to="/classes"><button className="signin_btn">Continue</button></NavLink>
                    </form>
                </div>
                <div className="create_accountinfo">
                    <p>New to Online Learning</p>
                   <NavLink to="/register"><button> Create your Account</button></NavLink> 
                </div>
            </div>

        </section>
    </>
  )
}

export default Sign_in