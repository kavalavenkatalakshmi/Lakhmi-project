import React from "react"
import { NavLink } from "react-router-dom"
import { FaCircleUser } from "react-icons/fa6";
import "./head.css"

// Example import statement correction

const Head = () => {
  return (
    <>
      <section className='head'>
        <div className='container flexSB'>
        <div className="sign_header">
        <NavLink to="/"><img src="./logo.png" alt="krishnalogo"></img></NavLink>
        </div>

          <div className='social'>
            <i className='fab fa-facebook-f icon'></i>
            <i className='fab fa-instagram icon'></i>
            <i className='fab fa-twitter icon'></i>
            <NavLink to="/login"><i className='fab fa-youtube icon'></i></NavLink>
          </div>

          
            <div className="log">
              <NavLink to="/login">Signin</NavLink>
              <FaCircleUser/>
            </div>
          
        </div>
      </section>
    </>
  )
}

export default Head