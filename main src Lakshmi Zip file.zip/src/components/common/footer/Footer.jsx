import React from "react"
import { blog } from "../../../dummydata"
import { NavLink } from "react-router-dom"
import "./footer.css"

const Footer = () => {
  return (
    <>
      <section className='newletter'>
        <div className='container flexSB'>
          <div className='left row'>
            <h1>Newsletter -Enter your Email to get our latest news and updates</h1>
            {/* <span>Far far away, behind the word mountains</span> */}
          </div>
          <div className='right row'>
            <input type='text' placeholder='Enter your email address' />
            <i className='fa fa-paper-plane'></i>
          </div>
        </div>
      </section>
      <footer>
        <div className='container padding'>
          <div className='box logo'>
           <div className="sign_header">
             <NavLink to="/"><img src="./logo.png" alt="krishnalogo"></img></NavLink>
             <p>Education is the most powerful weapon that we use to change the world!!</p>
           </div>            
          

            <i className='fab fa-facebook-f icon'></i>
            <i className='fab fa-twitter icon'></i>
            <i className='fab fa-instagram icon'></i>
          </div>
          <div className='box link'>
            <h2>Explore</h2>
            <ul>
              <li>About Us</li>
              {/* <li>Services</li> */}
              <li>Courses</li>
              {/* <li>Pricing</li> */}
              <li>Contact us</li>
            </ul>
          </div>
          <div className='box link'>
            <h2>Quick Links</h2>
            <ul>
              <li>Contact Us</li>
              <li>Pricing</li>
              <li>Terms & Conditions</li>
              {/* <li>Privacy</li> */}
              <li>Feedbacks</li>
            </ul>
          </div>
          <div className='box'>
            <h2>Recent Post</h2>
            {blog.slice(0, 3).map((val) => (
              <div className='items flexSB'>
                <div className='img'>
                  <img src={val.cover} alt='' />
                </div>
                <div className='text'>
                  <span>
                    <i className='fa fa-calendar-alt'></i>
                    <label htmlFor=''>{val.date}</label>
                  </span>
                  <span>
                    <i className='fa fa-user'></i>
                    <label htmlFor=''>{val.type}</label>
                  </span>
                  <h4>{val.title.slice(0, 40)}...</h4>
                </div>
              </div>
            ))}
          </div>
          <div className='box last'>
            <h2>Having any Questions?</h2>
            <ul>
              <li>
                <i className='fa fa-map'></i>
                   <p> Karakambadi, renigunta, Tirupati, Andhra Pradesh-517520</p>               
              </li>
              <li>
                <i className='fa fa-phone-alt'></i>
                +91 7330633684
              </li>
              {/* <li>
                <i className='fa fa-paper-plane'></i>
                info@yourdomain.com
              </li> */}
              <li>
              <i className='fa fa-envelope'></i>
              kavalalakshmi143@gmail.com
              </li>
            </ul>
          </div>
        </div>
      </footer>
      <div className='legal'>
        <p>
          Copyright ©2024 All rights reserved | This online learning platform is Designed & Created by Lakshmi<i className='fa fa-heart'></i>
        </p>
      </div>
    </>
  )
}

export default Footer